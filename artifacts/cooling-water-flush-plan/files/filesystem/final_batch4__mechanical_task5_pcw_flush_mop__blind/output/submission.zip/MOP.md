# Method of Procedure (MOP) and Engineering Design Basis
**Project:** Tull Creek Data Hall — Process Cooling Water (PCW) Cleaning, Flushing, and Passivation Turnover Package  
**Governing Specification:** Section 23 25 16 (Rev 3, 2026-07-14), Section 23 21 16 (Rev 3, 2026-07-14), Section 01 91 13 (Rev 2, 2026-05-28)

---

## 1. Design Basis & Governing Constraints by Circuit

Per Section 23 25 16 cl. 1.6, the binding governing constraint and its relative margin — defined as `(limit - achieved)/limit` for an upper limit and `(achieved - limit)/limit` for a lower limit, expressed as a decimal fraction — for each of the eight PCW circuits (`C1` through `C8`) are:

```text
GOVERNING CONSTRAINT C1: flushing_velocity (margin 0.0152)
GOVERNING CONSTRAINT C2: rinse_conductivity (margin 0.0198)
GOVERNING CONSTRAINT C3: rinse_conductivity (margin 0.0198)
GOVERNING CONSTRAINT C4: rinse_conductivity (margin 0.0107)
GOVERNING CONSTRAINT C5: flushing_velocity (margin 0.0075)
GOVERNING CONSTRAINT C6: rinse_conductivity (margin 0.0289)
GOVERNING CONSTRAINT C7: rinse_conductivity (margin 0.0107)
GOVERNING CONSTRAINT C8: rinse_conductivity (margin 0.0359)
```

### 1.1 Complete Multi-Parameter Margin Matrix (All Quantities & Constraint Families)
Because Section 23 25 16 cl. 1.6 notes that a constraint may be expressed in more than one quantity (for example, rinse performance in conductivity `uS/cm` or in displacements `n`), the table below reports the exact relative margin across every hydraulic, rinse, equipment, and electrical constraint family for each circuit, plus programme-level water and sewer discharge margins:

| Circuit | Governing Family | Governing Margin | Velocity Margin `(v - v_min)/v_min` | Pump Head Margin `(H_avail - H_req)/H_avail` | Rinse Conductivity Margin `(676.5 - C_n)/676.5` | Rinse Displacement Margin `(n_r - n_min)/n_min` | Power Margin `(kW_avail - kW)/kW_avail` | Equipment dP Margin `(dP_max - dP)/dP_max` |
|---|---|---|---|---|---|---|---|---|
| C1 | `flushing_velocity` | `0.0152` | `0.0152` (3.33 vs 3.28 ft/s) | `0.2291` (90.20 vs 117.00 ft) | `0.0198` (663.10 vs 676.5 uS/cm) | `0.0707` (6 vs 5.60 passes) | `0.5000` (75 vs 150 kW) | N/A (bypassed/0 dP) |
| C2 | `rinse_conductivity` | `0.0198` | `0.6025` (6.41 vs 4.00 ft/s) | `0.3849` (89.19 vs 145.00 ft) | `0.0198` (663.10 vs 676.5 uS/cm) | `0.0707` (6 vs 5.60 passes) | `0.5000` (75 vs 150 kW) | N/A (bypassed/0 dP) |
| C3 | `rinse_conductivity` | `0.0198` | `0.3875` (5.55 vs 4.00 ft/s) | `0.3951` (87.71 vs 145.00 ft) | `0.0198` (663.10 vs 676.5 uS/cm) | `0.0707` (6 vs 5.60 passes) | `0.2105` (75 vs 95 kW) | N/A (bypassed/0 dP) |
| C4 | `rinse_conductivity` | `0.0107` | `0.2500` (5.00 vs 4.00 ft/s) | `0.1023` (126.57 vs 141.00 ft) | `0.0107` (669.24 vs 676.5 uS/cm) | `0.0362` (8 vs 7.72 passes) | `0.6667` (30 vs 90 kW) | N/A (bypassed/0 dP) |
| C5 | `flushing_velocity` | `0.0075` | `0.0075` (4.03 vs 4.00 ft/s) | `0.0207` (131.23 vs 134.00 ft) | `0.0107` (669.24 vs 676.5 uS/cm) | `0.0362` (8 vs 7.72 passes) | `0.6667` (30 vs 90 kW) | N/A (bypassed/0 dP) |
| C6 | `rinse_conductivity` | `0.0289` | `0.2500` (5.00 vs 4.00 ft/s) | `0.0692` (131.24 vs 141.00 ft) | `0.0289` (656.94 vs 676.5 uS/cm) | `0.1190` (8 vs 7.15 passes) | `0.6667` (30 vs 90 kW) | N/A (bypassed/0 dP) |
| C7 | `rinse_conductivity` | `0.0107` | `0.3537` (4.44 vs 3.28 ft/s) | `0.0878` (135.31 vs 148.33 ft) | `0.0107` (669.24 vs 676.5 uS/cm) | `0.0362` (8 vs 7.72 passes) | `0.3333` (30 vs 45 kW) | N/A (bypassed/0 dP) |
| C8 | `rinse_conductivity` | `0.0359` | `0.5884` (5.21 vs 3.28 ft/s) | `0.1405` (144.56 vs 168.20 ft) | `0.0359` (652.20 vs 676.5 uS/cm) | `0.1563` (6 vs 5.19 passes) | `0.7500` (30 vs 120 kW) | `0.0400` (24.0 vs 25.0 ft) |

- **Programme Cumulative Sewer Cap Margin (`SW-03 Rev B`):** Limit = `500,000.00 gal`, Achieved = `496,284.06 gal`, Relative Margin = `(500,000 - 496,284.06) / 500,000 = 0.0074` (`3,715.94 gal` margin).
- **Daily Water Allocation Margin (`SW-01` & `SI-04`):** Peak normal-day draw = `87,577.63 gal` vs `92,000.00 gal` limit (margin `0.0481`); Day 2 draw = `59,837.39 gal` vs `61,000.00 gal` limit (margin `0.0191`); Day 3 draw = `60,102.25 gal` vs `61,000.00 gal` limit (margin `0.0147`); Day 6 outage draw = `0.00 gal` vs `30,000.00 gal` limit (margin `1.0000`).
- **Contractual Turnover Schedule Margin (`CX-01 Rev B`):**
  - `TM-1` (Hydrostatic testing complete): Limit = `144.00 h` (Day 6), Achieved = `8.00 h` (margin `0.9444`).
  - `TM-2` (Chemical cleaning complete): Limit = `528.00 h` (Day 22), Achieved = `275.47 h` (margin `0.4783`).
  - `TM-3` (Passivation film formation complete): Limit = `1056.00 h` (Day 44), Achieved = `613.52 h` (margin `0.4190`).
  - `TM-4` (System turnover to Owner): Limit = `1128.00 h` (Day 47), Achieved = `626.84 h` (margin `0.4443`).

---

## 2. Circuit Boundaries, Metallurgy, Volumes, and Hydraulics

Circuit boundaries were established by tracing the tie-in valve pairs (`TI-C1-01/02` through `TI-C8-01/02`, Schedule `M-603`) on the governing Revision C P&ID sheets (`M-PID-101` through `M-PID-104`) and isometric sheets (`M-ISO-201` through `M-ISO-204`). All hydraulic calculations follow `DOE-HDBK-1012/3-92` and `Section 23 25 16 cl. 3.2` using water at `68 degF` ($\rho = 62.30\text{ lbm/ft}^3$, $\nu = 1.08 \times 10^{-5}\text{ ft}^2/\text{s}$), Colebrook-White friction factors solved iteratively with roughness values from `Section 23 21 16 cl. 2.2` (`0.00015 ft` carbon steel, `0.0005 ft` galvanized steel, `0.000005 ft` drawn copper, `0.0008 ft` temporary lay-flat hose), fitting equivalent lengths $\sum(L/D)$ from `M-601`, static lifts from `M-ISO-201..204`, `300 ft` temporary hose and `40-mesh` basket strainer losses from `VD-05` ($\Delta H_{\text{str}} = 11(Q_{\text{skid}}/600)^2\text{ ft w.c.}$), and pump curves from `VD-01` (`FS-600`) and `VD-02` (`FS-1200`).

| Circuit | P&ID / Iso | Location & Panel | Pipe Lines (`M-601`) | Equipment (`M-602`) | Metallurgy | Flush Vol $V_f$ (gal) | System Vol $V_s$ (gal) | Skid Assigned | Flow $Q$ (gpm) | Gov. Seg & ID (in.) | Min Vel (ft/s) | $H_{\text{req}}$ / $H_{\text{avail}}$ (ft w.c.) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **C1** | `M-PID-101` / `M-ISO-201` | `MER-1` (`TP-MER-1`, 150 kW) | `1041, 1042, 1043 (x4), 1044 (x4)` | `PMP-101` (2400 gal, in path), `BT-101` (5000 gal, in path) | Carbon Steel | 32,983.40 | 32,983.40 | `FS-1200-A` | 1200.0 | `1043` (6.065) | 3.33 ($\ge 3.28$) | 90.20 / 117.00 |
| **C2** | `M-PID-102` / `M-ISO-201` | `MER-1` (`TP-MER-1`, 150 kW) | `2011, 2012, 2013 (x3)` | `HX-201A` (2350 gal, bypassed) | Carbon Steel, 316 SS, Nitrile | 5,596.03 | 7,946.03 | `FS-1200-A` | 1000.0 | `2011` (7.981) | 6.41 ($\ge 4.00$) | 89.19 / 145.00 |
| **C3** | `M-PID-102` / `M-ISO-202` | `MER-2` (`TP-MER-2`, 95 kW) | `2021, 2022, 2023 (x2)` | `HX-201B` (2350 gal, bypassed) | Carbon Steel, 316 SS, Nitrile | 6,203.19 | 8,553.19 | `FS-1200-A` | 1000.0 | `2023` (6.065) | 5.55 ($\ge 4.00$) | 87.71 / 145.00 |
| **C4** | `M-PID-103` / `M-ISO-203` | `L3-N` (`TP-L3-N`, 90 kW) | `4021, 4022, 4023 (x2), 4024 (x4)` | `CDU-301` (1550 gal, bypassed), `CP-311` (1030 gal, bypassed) | Carbon Steel, 316 SS, Copper | 5,956.64 | 8,536.64 | `FS-600-A` | 450.0 | `4021` (6.065) | 5.00 ($\ge 4.00$) | 126.57 / 141.00 |
| **C5** | `M-PID-103` / `M-ISO-203` | `L3-S` (`TP-L3-S`, 90 kW) | `4031, 4032, 4033 (x3), 4034 (x4)` | `CDU-302` (1550 gal, bypassed), `CP-321` (1030 gal, bypassed) | Carbon Steel, 316 SS, Copper | 6,405.83 | 8,985.83 | `FS-600-A` | 480.0 | `4033` (4.026) | 4.03 ($\ge 4.00$) | 131.23 / 134.00 |
| **C6** | `M-PID-103` / `M-ISO-203` | `L3-W` (`TP-L3-W`, 90 kW) | `4041, 4042, 4043 (x3)` | `CP-331` (1450 gal, bypassed) | Carbon Steel, Copper, 6061-T6 Al | 4,227.15 | 5,677.15 | `FS-600-A` | 450.0 | `4041` (6.065) | 5.00 ($\ge 4.00$) | 131.24 / 141.00 |
| **C7** | `M-PID-101` / `M-ISO-204` | `ROOF` (`TP-ROOF`, 45 kW) | `5011, 5012, 5013 (x4)` | `CL-401` (1950 gal, bypassed) | Carbon Steel, Copper (Al fin dry) | 4,085.96 | 6,035.96 | `FS-600-A` | 400.0 | `5011` (6.065) | 4.44 ($\ge 3.28$) | 135.31 / 148.33 |
| **C8** | `M-PID-104` / `M-ISO-202` | `YARD` (`TP-YARD`, 120 kW) | `6011, 6012, 6013 (x2)` | `ST-601` (3750 gal, in path) | Hot-Dip Galvanized Steel | 5,790.75 | 5,790.75 | `FS-600-A` | 240.0 | `6013` (3.068) | 5.21 ($\ge 3.28$) | 144.56 / 168.20 |

---

## 3. Resolution of Document Conflicts and Document Defects Found

In accordance with `Section 23 25 16 cl. 1.6`, all conflicts and defects across the project document library were identified and resolved as follows:

1. **Defect in Hydrostatic Test Record `CX-02_Hydrostatic_Test_Record_partial.csv` (Missing Pressure Chart Evidence for `C3, C5, C6, C7`):**
   - `CX-02` lists all eight circuits as `"PASS"` citing pressure charts `TR-0412` through `TR-0419`. However, inspection of the `commissioning/` archive shows that only **`TR-0412` (`C1`), `TR-0413` (`C2`), `TR-0415` (`C4`), and `TR-0419` (`C8`)** exist on file; charts **`TR-0414` (`C3`), `TR-0416` (`C5`), `TR-0417` (`C6`), and `TR-0418` (`C7`) are missing**.
   - **Resolution:** Under `Section 01 91 13 cl. 1.3` (*"a result whose cited evidence is not on file is not an accepted result"*) and `Section 23 21 16 cl. 3.3` (*"Circuits recorded as tested and accepted in CX-02 shall not be retested; retesting an accepted circuit is a change in scope. Any circuit not so recorded shall be tested before chemical cleaning begins"*), `C1, C2, C4, C8` are accepted and not retested (`HYDRO` omitted), whereas `C3, C5, C6, C7` are hydrostatically tested at `1.5 x 85 = 127.5 psig` (`<= 150 psig` temporary hose/strainer rating and `<= 230/300 psig` equipment rating) for `2.00 h` (`120 min`) on Day 0 (`0.00..8.00 h`, well before `TM-1` at `144.00 h`).
2. **Conflict on Sanitary Sewer Cumulative Discharge Cap (`SW-03` & `RFI-031` vs `SW-03 Rev B`):**
   - Initial authorization `SW-03` and `RFI-031` state a cumulative sewer discharge cap of `540,000 gal`. Subsequent `SW-03_Sanitary_Sewer_Discharge_Authorization_RevB.pdf` (`IWD-2026-0417 Rev B`) reduces the cumulative cap to **`500,000 gal`** (`$3.40/1,000 gal`).
   - **Resolution:** `SW-03 Rev B` governs. In addition to hauling the spent chemical cleaning effluent of `C4, C5, C7` (`CL-100` on copper pipe: `Cu = 3.4 mg/L > 2.0 mg/L` local limit in `SW-03 Rev B`) and `C8` (`CL-210` on galvanized steel: `Zn = 5.5 mg/L > 4.0 mg/L` local limit in `SW-03 Rev B`), which leaves `500,511.21 gal` of otherwise sewerable effluent (`511.21 gal` over the `500,000 gal` cap), the spent chemical cleaning charge of `C6` (`4,227.15 gal`) is also routed to `HAUL` per `RFI-031`. This brings cumulative sewer discharge to **`496,284.06 gal <= 500,000.00 gal`** and total tanker haul to **`26,466.33 gal`**.
3. **Conflict on Passivation Film-Formation Hold Duration (`UFC 3-240-13FN` vs `UFC 3-230-13 Table 5-11` vs `Tables 5-14 & 5-15`):**
   - Cancelled `UFC 3-240-13FN` (2005) listed shorter holds; current `UFC 3-230-13` (2023) `Table 5-11` lists `5-6 days` (TTA) and `10-12 days` (Molybdate/Polysilicate), while `Tables 5-14 & 5-15` (invoked by `cl. 5-7.3.2.4` specifically for passivation) specify **`14-21 days`**.
   - **Resolution:** Per `Section 23 25 16 cl. 1.2 & 3.5`, the current edition `UFC 3-230-13` (2023) and the tables identified for passivation (`Tables 5-14 & 5-15`) govern: a **`14-day` (`336.00 h`)** occupied film-formation hold is applied to all eight circuits.
4. **Conflict Between `UFC 3-230-13 Table 6-2` Selection Table and Controlling Paragraph Text (`cl. 6-2.2.5`) for Aluminium/Galvanized Circuits (`C6` & `C8`):**
   - `Table 6-2` lists `Polysilicate-azole` only opposite `"Diesel engine jacket"`, whereas paragraph `6-2.2.5` explicitly states that `Polysilicate-Azole` is beneficial when aluminum metal is present in closed process cooling water loops, and `cl. 5-7.3.2` recommends polysilicate at `pH 7.5-8.5` for galvanized steel.
   - **Resolution:** Per `Section 23 25 16 cl. 3.5` (*"the paragraph text of the programme governs"*), `Polysilicate-Azole` (`PS-330`, plus `TA-90` on `C6`) at `pH 7.5-8.5` is selected for `C6` (`CP-331` aluminium cold plates, `VD-04`) and `C8` (hot-dip galvanized steel riser and `ST-601`, `RFI-022`), while `Molybdate-Azole` (`MO-500`, plus `TA-90` on `C4, C5, C7` and `SA-100` soda ash for `pH 8.5-9.5`) is selected for `C1, C2, C3, C4, C5, C7` (`cl. 6-2.2.3`).
5. **Rejection of `NB-700` (Nitrite-Borax-Azole Blend, `VD-06 Note 4`):**
   - `VD-06 Note 4` states that `NB-700` is offered for comparison only. Per `UFC 3-230-13 cl. 6-2.2.2 & 6-2.3`, nitrite operates at `pH 9.0-9.5` (corrosive to `C6` aluminium and `C8` galvanized steel) and serves as a nutrient for bacterial growth (`SW-02` makeup water already carries `120 CFU/mL` heterotrophic bacteria, risking violation of the `< 1,000 CFU/mL` turnover gate in `Table 6-3`). Therefore, `NB-700` is rejected.
6. **Conflict Between `VD-03` (`46 ft w.c.`) and `M-602` (`58 ft w.c.`) on Plate Heat Exchangers `HX-201A/B`:**
   - `VD-03` lists `46 ft w.c.` at `610 gpm`, which `M-602 Note 6` and `VD-03 Note 5` clarify is the pressure drop *developed* at rated flow, whereas `58 ft w.c.` in `M-602` is the maximum allowable pressure drop. During flushing and cleaning, `HX-201A` and `HX-201B` are isolated behind full-size temporary bypass spools (`M-602 Note 4`).
7. **Makeup Water Hardness (`268 mg/L` in `SW-02` vs `250 mg/L` Threshold in `UFC 3-230-13 cl. 6-2.2.3 & 6-2.2.5`) and Softener `SF-1` (`SV-2` on `C-101`):**
   - `SW-02` reports makeup water total hardness of `268 mg/L as CaCO3` (`> 250 mg/L`). Drawing `C-101` provides softened water outlet `SV-2` downstream of the construction meter (`SF-1`, capacity `88,000 grains/day` = `5,617 gal/day` at `268 mg/L`, `< 20 mg/L` outlet hardness, regenerated overnight). Under `RETAIN_AND_TOP_UP`, drawing the `FINAL_FILL` top-up volume (`Vs - Vf = 1,450` to `2,580 gal` per circuit on `C2..C7`) and a `4,000 gal` portion of `C1` / `700 gal` portion of `C8` final rinse displacement through `SV-2` brings every circuit's standing hardness at turnover below `235 mg/L <= 250 mg/L` while staying within `SF-1`'s `88,000 grains/day` capacity.
8. **Construction Water Utility Restrictions (`SI-04`) and Flush Skid Delivery Delay (`SI-05`):**
   - `SI-04` reduces metered construction water from `62,000 gal/day` (`SW-01`) to `31,000 gal/day` on Days 2 and 3 (`48..96 h`) and `0 gal/day` on Day 6 (`144..168 h`). `SI-05` delays delivery of `FS-1200-A` to `48.00 h` (start of Day 2). The master schedule respects all utility caps and leaves Day 6 completely idle (`0 gal` drawn, `0` skids held, `0` crews engaged).

---

## 4. Reviewed and Rejected / Superseded / Non-Adopted Documents

Per the constraint register rules, the following documents in the project library were reviewed and excluded from `constraint_register.csv` because they are cancelled, superseded, or out of scope:
- **`standards/UFC_3-240-13FN_Industrial_Water_Treatment_2005_CANCELLED.pdf`:** Explicitly cancelled by `UFC 3-230-13` (2023) and prohibited by `Section 23 25 16 cl. 1.2`.
- **`standards/40_CFR_122_NPDES_Permit_Programs_2024.pdf`:** Applies to direct point-source discharges to surface waters (`Tull Creek`). Prohibited by `RFI-031` (*"No discharge to the storm system or to Tull Creek is authorized under any circumstances"*); discharge is to POTW manhole `MH-14` under `40 CFR 403`.
- **`drawings/M-PID-103_Pcw_Cdu_Distribution_RevA.dxf`:** Superseded by `M-PID-103_Pcw_Cdu_Distribution_RevC.dxf` per `M-601 Note 5`.
- **`site/SW-03_Sanitary_Sewer_Discharge_Authorization.pdf` (Rev 0):** Superseded by `SW-03_Sanitary_Sewer_Discharge_Authorization_RevB.pdf` (`IWD-2026-0417 Rev B`), which reduced the cumulative sewer cap from `540,000 gal` to `500,000 gal`.
- **`specs/22_11_23_Domestic_Water_Pumps_excerpt.docx`:** Covers domestic water booster pumps (`120 gpm at 65 psi`) and plumbing code disinfection; `cl. 2.1 & 3.1` explicitly state it does not apply to the PCW system.
- **`vendor_data/VD-08_Air_Cooled_Chiller_Submittal.pdf`:** Covers comfort cooling chiller `ACCH-500`; `Note 1` explicitly states it is not part of the PCW loop.
- **`correspondence/RFI-009_Response_Roof_Curb_Flashing.docx`:** Architectural roof curb flashing detail (`6/A-501`) with no mechanical or PCW content.

---

## 5. Step-by-Step Execution Narrative

### 5.1 Pre-Start & Excluded Contractor Lump-Sum Scope (`Section 23 25 16 cl. 3.10 f`)
Within the lump-sum mobilisation (no separate price line), the Contractor provides:
1. **Hydrostatic Test Pump Rig:** Positive-displacement hydrostatic test pump with calibrated chart recorder capable of `127.5 psig` (`FS-600` and `FS-1200` centrifugal flush skids develop `182–212 ft w.c.` = `79–92 psig` shutoff head and are not used for hydrostatic testing).
2. **Portable Cascade Transfer Holding Tank:** `6,500 gal` clean poly nurse tank and transfer hose set used to transfer cascaded final-rinse displacements (`C1 -> C5 -> C3 -> C4 -> C8 -> C2 -> C6 -> C7`) between tie-in pads (`MER-1, L3-S, MER-2, L3-N, YARD, L3-W, ROOF`).
3. **50-Micron Trim Filtration:** Slip-stream / inline `50-micron` cartridge filter housing installed prior to removing bypass spools on cold-plate circuits `C4` (`CP-311`), `C5` (`CP-321`), and `C6` (`CP-331`) to bridge the `40-mesh` (`380-micron`) temporary skid strainer (`VD-05`) down to the `50-micron` limit of `M-602` and `VD-04`.

### 5.2 Stage-by-Stage Execution Procedure
1. **Stage 1 — `HYDRO` (Circuits `C3, C5, C6, C7` only; Day 0, `0.00..8.00 h`):**
   - Verify temporary bypass spools fitted on `HX-201B` (`C3`), `CDU-302/CP-321` (`C5`), `CP-331` (`C6`), and `CL-401` (`C7`). Fill each circuit with `V_f` of metered construction water, vent at high-point air vents (`AV-C3-01, AV-C5-01, AV-C6-01, AV-C7-01`), pressurize to `127.5 psig` (`1.5 x 85 psig`), and hold for `120 minutes` (`2.00 h`) with zero pressure loss and zero visible leakage, recording signed chart records. Drain `V_f` to `MH-14` (`SEWER`, `pH 7.6`, `68 degF`).
2. **Stage 2 — `INITIAL_FLUSH` (All Circuits `C1..C8`, `passes = 1`):**
   - Connect assigned flush skid (`FS-1200-A` on `C1, C2, C3`; `FS-600-A` on `C4, C5, C6, C7, C8`) with `300 ft` lay-flat hose and clean `40-mesh` basket strainer at circuit tie-in valves. Verify all bypass spools installed (`HX-201A/B, CDU-301/302, CP-311/321/331, CL-401`) and `PMP-101, BT-101, ST-601` open in the flushed path (`ST-601` drop at `240 gpm` is `24.0 ft w.c. <= 25.0 ft w.c.` limit). Flush `1` full circuit flush volume (`V_f`) at declared flow (`1200, 1000, 1000, 450, 480, 450, 400, 240 gpm`), verifying minimum leg velocity ($\ge 3.28\text{ ft/s}$ on `C1, C7, C8`; $\ge 4.00\text{ ft/s}$ on `C2..C6`). Drain `V_f` to `MH-14` (`SEWER`) and clean strainer basket.
3. **Stage 3 — `CHEM_CLEAN` (All Circuits `C1..C8`, `24.00 h` occupied circulation):**
   - Fill circuit with `V_f` makeup water. Dose cleaner on system volume `V_s`: `CL-100` (`1.5 gal / 1,000 gal Vs`) on `C1, C2, C3, C4, C5, C7` and `CL-210` (`2.0 gal / 1,000 gal Vs`) on `C6, C8`, together with `PD-45` polyacrylate dispersant at `5.0 ppm` active polymer (`UFC 3-230-13 cl. 5-3.7`). Circulate at full flushing flow for `24.00 occupied hours`.
   - At completion, sample for pH/temperature/metals: discharge `C1, C2, C3` spent solution (`pH 8.4`, `68 degF`, `0 mg/L` Cu/Zn) to `MH-14` (`SEWER`), and haul `C4, C5, C6, C7, C8` spent solution (`26,466.33 gal` total) via vacuum tanker at the `YARD` pad (`HAUL`). Clean all strainer baskets.
4. **Stage 4 — `DRAIN_RINSE` (All Circuits `C1..C8`, `6` or `8` displacements with 7-link cascade):**
   - Execute whole-displacement rinses of flush volume `V_f` until effluent conductivity $\le 676.5\text{ uS/cm}$ (`1.10 x 615 uS/cm`), `pH 7.5–8.5`, and `TSS <= 2.0 mg/L`: `n_r = 6` passes on `C1, C2, C3, C8` ($\eta = 0.62$) and `n_r = 8` passes on `C4, C5, C6, C7` ($\eta = 0.45$).
   - Execute the monotonically non-increasing volume cascade chain **`C1 (32,983.40 gal) -> C5 (6,405.83 gal) -> C3 (6,203.19 gal) -> C4 (5,956.64 gal) -> C8 (5,790.75 gal) -> C2 (5,596.03 gal) -> C6 (4,227.15 gal) -> C7 (4,085.96 gal)`**, transferring one receiver `V_f` displacement from each donor's final rinse effluent after donor rinse completion. Leave each circuit full at the end of its final rinse displacement.
5. **Stage 5 — `PASSIVATE` (All Circuits `C1..C8`, `0` water draw, `0` effluent):**
   - Dose passivation inhibitors into the standing final rinse water on system volume `V_s` per `UFC 3-230-13 Tables 5-14 & 5-15`: `MO-500` at `50.0 ppm as Mo` on `C1, C2, C3, C4, C5, C7`; `PS-330` at `40.0 ppm as SiO2` on `C6, C8`; plus `TA-90` at `10.0 ppm as TTA` on copper-bearing circuits `C4, C5, C6, C7`. Control pH to `7.5–7.9` (intersection of `[7.5, 8.5]` and `[6.5, 7.9]` per `Section 23 25 16 cl. 3.8`) on `C4..C7` and `7.5–8.5` on `C1, C2, C3, C8`. Circulate for `1` displacement plus `30 minutes` (`0.50 h`) and verify `PASSIVATION` gate sample.
6. **Stage 6 — `HOLD` (All Circuits `C1..C8`, `336.00 h` = `14.0 days` unattended):**
   - Release flush skid and commissioning crew; hold the passivation charge for `336.00 occupied hours` (`14 days` per `Tables 5-14 & 5-15`).
7. **Stage 7 — `FINAL_FILL` & Turnover (`RETAIN_AND_TOP_UP`, Day 26, `624.00..626.84 h`):**
   - Remove temporary bypass spools (`HX-201A/B, CDU-301/302, CP-311/321/331, CL-401`), retaining the passivation charge (`RETAIN_AND_TOP_UP`) and topping up `V_s - V_f` (`13,260.00 gal` total) with softened makeup water (`SV-2`).
   - Add incremental maintenance inhibitor dose on `V_s` to bring `C1, C2, C3, C4, C5, C7` to `100.0 ppm as Mo` (`+50.0 ppm` `MO-500`) and `pH 8.5–9.5` (`SA-100` soda ash at `50.0 ppm`), `C6, C8` to `80.0 ppm as SiO2` (`+40.0 ppm` `PS-330`) and `pH 7.5–8.5`, and `C4, C5, C6, C7` to `>= 10.0 ppm as TTA` (`TA-90`).
   - Recirculate for `>= 30 minutes` (`0.50 h`) plus top-up displacement time, sample while circulating to verify `TURNOVER` gate (`Mo >= 100 ppm` or `SiO2 >= 80 ppm`, `TTA >= 10 ppm`, `pH` in band, `Total aerobic bacteria <= 1,000 CFU/mL`), and remove all temporary `40-mesh` strainers prior to `TM-4`.

---

## 6. Resource, Procurement, and Cost Summary (`resources.json`)

- **Skid Fleet Utilization:** `FS-1200-A` held on `6` calendar days (`Days 2, 3, 4, 5, 7, 9, 10, 26` — `8` active unit-days total at `$790/day` = `$6,320.00`); `FS-600-A` held on `8` active unit-days (`Days 5, 7, 8, 9, 10, 11, 26` at `$430/day` = `$3,010.00`); `FS-600-B` held `0` days (`$0.00`). Total skid cost = **`$9,330.00`**.
- **Commissioning Crew Utilization:** `CREW-1` and `CREW-2` (never exceeding `2` simultaneous crews) across `23` total 12-hour shifts at `$820.00/shift` = **`$18,860.00`**.
- **Water Balance & Cost:** Total water drawn = **`607,259.34 gal`** (`537,694.05 gal` metered at `$6.20/kgal` + `69,565.29 gal` trucked at `$19.80/kgal`; programme-wide average rate = `$7.7580/kgal`) = **`$4,711.10`**.
- **Effluent Balance & Cost:** Total sewer discharge to `MH-14` = **`496,284.06 gal`** at `$3.40/kgal` (`$1,687.37`); total vacuum tanker haul = **`26,466.33 gal`** at `$168.00/kgal` (`$4,446.34`). Standing system volume at turnover = **`84,508.95 gal`** (`496,284.06 + 26,466.33 + 84,508.95 = 607,259.34 gal`, exact mass balance). Total effluent cost = **`$6,133.71`**.
- **Chemical Procurement & Cost:** Whole packages rounded up per dosing row (`Section 23 25 16 cl. 3.10 e`), ordered ahead of lead times (`order_by_day` from `-16` to `+21`): `CL-100` (`26` pails), `CL-210` (`6` pails), `PD-45` (`8` bottles), `MO-500` (`16` pails), `PS-330` (`4` pails), `TA-90` (`8` bottles), `SA-100` (`6` bags). Total chemical cost = **`$8,240.00`**.
- **Total Programme Cost (`total_usd`):** **`$47,274.81`**.

---

## 7. Hazard Communication & Chemical Safety Plan (`29 CFR 1910.1200` & `VD-07`)

In compliance with `29 CFR 1910.1200` (Hazard Communication Standard) and the Safety Data Sheets in `VD-07_SDS_pack.pdf` (supplier: **Cascadia Water Technologies**, 24-hour emergency telephone: **`1-800-555-0142`**):

1. **On-Site SDS & Container Labeling (`29 CFR 1910.1200(g)` & `CX-03 Item 10`):**
   - Bound physical copies of `VD-07_SDS_pack.pdf` are maintained at the `YARD` chemical staging pad and at each active tie-in work station (`MER-1, MER-2, L3-N, L3-S, L3-W, ROOF, YARD`) prior to bringing any product on site. All primary pails, bottles, bags, and secondary transfer containers carry legible GHS hazard labels stating product identifier, signal word, hazard statements, and pictograms.
2. **Product-Specific GHS Classifications & Signal Words (`VD-07 Section 2 & 3`):**
   - **`CL-100` (Alkaline Pre-Operational Cleaner, 22% active, pH 10.4):** `Skin Corr. 1B, Eye Dam. 1` — Signal Word: **DANGER**.
   - **`CL-210` (Neutral-pH Cleaner for Galvanized & Aluminium Systems, 18% active, pH 8.2):** `Skin Corr. 1B, Eye Dam. 1` — Signal Word: **DANGER**.
   - **`SA-100` (Soda Ash / Sodium Carbonate, 99% Na2CO3):** `Skin Corr. 1B, Eye Dam. 1` — Signal Word: **DANGER**.
   - **`MO-500` (Sodium Molybdate Liquid Inhibitor, 10% Mo):** `Eye Irrit. 2A` — Signal Word: **WARNING**.
   - **`PS-330` (Polysilicate Liquid Inhibitor, 12% SiO2):** `Eye Irrit. 2A` — Signal Word: **WARNING**.
   - **`TA-90` (Tolyltriazole Solution, 50% TTA):** `Eye Irrit. 2A` — Signal Word: **WARNING**.
   - **`PD-45` (Polyacrylate Dispersant, 40% active polymer):** `Eye Irrit. 2A` — Signal Word: **WARNING**.
3. **Personal Protective Equipment & Engineering Controls (`VD-07 Section 8`):**
   - All crew members transferring, mixing, or dosing chemicals must wear **chemical splash goggles, full face shield, chemical-resistant gauntlet gloves (nitrile/neoprene), and a chemical-resistant apron**. Dosing is performed via closed suction/eductor lances into the circulating skid manifold.
4. **Emergency Eyewash, Quick-Drench Shower & First Aid (`VD-07 Section 4`):**
   - Aplumbed or self-contained ANSI-compliant **emergency eyewash and quick-drench safety shower station is positioned within 10 seconds (unobstructed travel) of every chemical handling and dosing point**.
   - In the event of eye contact, immediately flush eyes with copious water for at least **15 minutes** while holding eyelids open and seek medical attention; call Cascadia Water Technologies emergency response at `1-800-555-0142`.
5. **Spill Containment & Transport (`VD-07 Section 14`):**
   - All chemical packages (`5 gal` pails, `1 gal` bottles, `50 lb` bags; not DOT-regulated in supplied package sizes per `Section 14`) are stored on secondary containment spill pallets (`>= 110%` of largest container volume) with soda ash/absorbent spill kits at each pad.
