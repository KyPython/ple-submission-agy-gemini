# Basis of Estimate — Meridian Data Center (Phase 1, Data Hall 1)

## 1. Counting Conventions & Governing Clauses
All device quantities, locations, condition assignments, and bill of materials rows were compiled in strict accordance with `criteria/takeoff_criteria_manual.md` (Conventions `C1`–`C9` and Clauses `E-01`–`E-22`), `project/OPR.md`, `drawings/E-001_symbol_legend_and_general_notes.png`, and `drawings/E-002_device_and_mounting_schedule.md`:

- **C1 (Single Count / Match Lines — Clause E-05)**: Each device is counted exactly once. On `E-201` (Zone 1: SW), `E-202` (Zone 2: SE), `E-203` (Zone 3: NW), and `E-204` (Zone 4: NE), only devices inside each sheet's active zone boundary (within the match lines at Grid Line `3` `[x = 14.7 m]` and Grid Line `C` `[y = 14.7 m]`) are counted; devices shown in the shaded reference band beyond the match line are for reference only and are not double-counted.
- **C2 (Symbol Legend Authority — Clause E-02)**: All drawn symbols were identified solely against the symbol legend on `drawings/E-001_symbol_legend_and_general_notes.png` (Legend Note 1) and `drawings/E-002_device_and_mounting_schedule.md`.
- **C3 (Unresolved Symbols — Clauses E-04, E-04b)**: Any symbol appearing on a plan that is not in the legend on `E-001` is not a scheduled device, carries zero quantity in `takeoff.csv`, `locations.csv`, and `bom.csv`, and is listed with its sheet, view, and grid bay in Section 3 below.
- **C4 (Zero-Quantity Legend Entries — Clause E-03)**: Scheduled legend entries `R8` (`RECEPTACLE, SINGLE, 50 A, 250 V, WALL-MOUNTED`) and `F6` (`DETECTOR, SMOKE, PROJECTED BEAM, WALL-MOUNTED`) have zero instances on any plan and are reported with a quantity of `0` in `takeoff.csv`.
- **C5 (Keyed Notes — Clause E-06)**: Devices required by keyed notes `K1`–`K4` are included whether or not symbols are drawn:
  - **Keyed Note K1 (`E-211`)**: Requires 1 wall-mounted visible notification appliance (`F1`) at the midpoint of each structural column bay along the North (`W-N`) and South (`W-S`) perimeter walls (`UFC 3-600-01`). Across the 4 structural bays (`1–2`, `2–3`, `3–4`, `4–5`) on the South wall (`A1, A2, A3, A4`) and North wall (`D1, D2, D3, D4`) on `A-101`/`A-102`, this adds **8 × `F1`** in condition `DRY-MASONRY` on `E-211`.
  - **Keyed Note K2 (`E-201`–`E-204`)**: Requires 1 weather-resistant GFCI duplex receptacle with extra-duty while-in-use cover (`R5`) within 7.6 m (25 ft) of each CRAH unit (`UFC 3-520-01` §3-6.1.2; `Spec 26 20 00` §3.3). From `A-101`, `A-601`, and `M-101`, there are **28 CRAH units** in total (4 perimeter CRAH units `CRAH-01`..`CRAH-04` + 24 In-Row CRAH units `IRC-A01`..`IRC-F04` across Rows A–F, with 4 IRC units per row: 1 in Col 1, 2 in Col 2, and 1 in Col 3). Because `K2` names no wall, these **28 × `R5`** devices take condition `DRY-STUD` and are distributed by sheet and structural bay as:
    - `E-201` (Zone 1): **14 × `R5`** (`A1`: 3, `A2`: 5, `B1`: 2, `B2`: 4)
    - `E-202` (Zone 2): **6 × `R5`** (`A3`: 3, `A4`: 1, `B3`: 2)
    - `E-203` (Zone 3): **6 × `R5`** (`C1`: 2, `C2`: 4)
    - `E-204` (Zone 4): **2 × `R5`** (`C3`: 2)
    (In addition to these 28 unshown `K2` devices, 4 drawn `R5` devices appear in the Entry Vestibule on `E-201` [`A1`: 3, `B1`: 1, condition `DAMP`], yielding **32 × `R5`** total.)
  - **Keyed Note K3 (`E-201`–`E-204`)**: Requires 1 recessed two-gang floor box (`R7`) in the access floor at each Power Distribution Unit (`PDU`). From `A-101` and `A-601`, there are **6 PDU units** (`PDU-01`..`PDU-06`), located at the east end of Rows A–F (`x ≈ 20.8 m`, Column 3), adding **6 × `R7`** in condition `ACCESS-FLOOR`:
    - `E-202` (Zone 2): **4 × `R7`** (`A3`: 2 [`PDU-01`, `PDU-02`], `B3`: 2 [`PDU-03`, `PDU-04`])
    - `E-204` (Zone 4): **2 × `R7`** (`C3`: 2 [`PDU-05`, `PDU-06`])
  - **Keyed Note K4 (`E-211`)**: Requires 1 wall-mounted visible notification appliance (`F1`) within 1.5 m of each egress door on the corridor side. From `A-102`'s Door Schedule (`D-01` through `D-05`), `D-03` (`STOR. 103`, marked `NO` under egress) is excluded, leaving **4 egress doors**:
    - `D-01` (in 2-hr rated wall `P-R1`, Bay `A1`) -> `1 × F1` (`RATED-2HR`)
    - `D-02` (in 2-hr rated wall `P-R1`, Bay `D1`) -> `1 × F1` (`RATED-2HR`)
    - `D-04` (in west stud wall `W-W`, Bay `A1`) -> `1 × F1` (`DRY-STUD`)
    - `D-05` (in east stud wall `W-E`, Bay `B4`) -> `1 × F1` (`DRY-STUD`)
- **C6 (Governing Issue & Addendum 02 — Clause E-07)**: All drawing sheets carry baseline issue date `2026-07-24`, with Revision 1 (`2026-07-25`) and Revision 2 (`2026-07-27`) on `E-201`. **Addendum No. 02 (`addenda/ADD-02_addendum_two.md`), dated `2026-08-07`, postdates Revision 2 (`2026-07-27`) and therefore governs** for what it describes, while the sheets govern for everything else. Per `ADD-02` Item `02-1`, at the Revision 2 cloud in Grid Bay `A1` on `E-201`, the **3 duplex receptacles (`R1`)** (`raw=(2310,1069)`, `(1836,1069)`, `(1458,1069)`) are **DELETED**, and **2 quadraplex receptacles (`R2`)** are **ADDED** at the first and second deleted positions measured from the south (`raw=(2310,1069)` in `DRY-MASONRY` and `raw=(1836,1069)` in `RATED-2HR`).
- **C7 (Enlarged Plans — Clause E-08)**: The West Corridor/Entry Vestibule strip and East Service Corridor strip cross-referenced to `drawings/E-231_enlarged_electrical_plans.png` (Views 1–6), `drawings/E-232_enlarged_electrical_plans.png` (Views 7–10), and `drawings/E-233_enlarged_electrical_plans.png` (Views 11–14) are counted from those enlarged plans (`61` scheduled devices across Views 1–14).

### Per-Sheet Device Takeoff Summary (Clauses E-01, E-02, E-03, E-09, E-22)

| Type Mark | Description | E-201 | E-202 | E-203 | E-204 | E-211 | E-231 | E-232 | E-233 | Total |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `R1` | RECEPTACLE, DUPLEX, 20 A, 125 V, WALL-MOUNTED | 8 | 14 | 4 | 4 | 0 | 9 | 7 | 6 | **52** |
| `R2` | RECEPTACLE, QUADRAPLEX, 20 A, 125 V, WALL-MOUNTED | 2 | 0 | 0 | 0 | 0 | 0 | 3 | 3 | **8** |
| `R3` | RECEPTACLE, DUPLEX, GROUND-FAULT CIRCUIT INTERRUPTER, 20 A | 0 | 0 | 0 | 0 | 0 | 3 | 3 | 2 | **8** |
| `R4` | RECEPTACLE, DUPLEX, ISOLATED GROUND, 20 A, 125 V | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 2 | **6** |
| `R5` | RECEPTACLE, DUPLEX, WEATHER-RESISTANT, WITH EXTRA-DUTY WHILE-IN-USE COVER | 18 | 6 | 6 | 2 | 0 | 0 | 0 | 0 | **32** |
| `R6` | RECEPTACLE, DUPLEX, EMERGENCY BRANCH, 20 A, 125 V | 1 | 0 | 1 | 0 | 0 | 1 | 0 | 1 | **4** |
| `R7` | BOX, OUTLET, FLOOR, TWO-GANG, IN ACCESS FLOOR | 0 | 4 | 0 | 2 | 0 | 0 | 0 | 0 | **6** |
| `R8` | RECEPTACLE, SINGLE, 50 A, 250 V, WALL-MOUNTED | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | **0** |
| `J1` | BOX, JUNCTION, 100 MM SQUARE, CONCEALED | 11 | 7 | 7 | 8 | 0 | 4 | 1 | 0 | **38** |
| `P1` | BOX, PULL, 300 X 300 X 150 MM, SURFACE | 1 | 1 | 1 | 0 | 0 | 2 | 1 | 1 | **7** |
| `F1` | APPLIANCE, NOTIFICATION, VISIBLE, WALL-MOUNTED | 0 | 0 | 0 | 0 | 12 | 0 | 0 | 0 | **12** |
| `F2` | APPLIANCE, NOTIFICATION, AUDIBLE-VISIBLE, WALL-MOUNTED | 0 | 0 | 0 | 0 | 1 | 2 | 0 | 1 | **4** |
| `F3` | STATION, MANUAL, FIRE ALARM, WALL-MOUNTED | 0 | 0 | 0 | 0 | 2 | 0 | 0 | 1 | **3** |
| `F4` | DETECTOR, SMOKE, PHOTOELECTRIC, CEILING-MOUNTED | 0 | 0 | 0 | 0 | 6 | 0 | 0 | 0 | **6** |
| `F5` | DETECTOR, SMOKE, PHOTOELECTRIC, IN ACCESS FLOOR | 0 | 0 | 0 | 0 | 25 | 0 | 2 | 3 | **30** |
| `F6` | DETECTOR, SMOKE, PROJECTED BEAM, WALL-MOUNTED | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | **0** |
| `D1` | DETECTOR, SMOKE, DUCT, FURNISHED UNDER DIVISION 23 | 0 | 0 | 0 | 0 | 25 | 1 | 1 | 0 | **27** |

---

## 2. Unresolved Symbols (Clauses E-04, E-04b, E-22)
Per Convention `C3` and `E-001` Legend Note 5, the following **2 symbol instances** appear on the enlarged plans as a **square with an inscribed diamond** (`22×22 px` square containing an inscribed diamond, with no letter or legend match on `E-001`). They are not scheduled devices and carry **zero quantity** in `takeoff.csv`, `locations.csv`, and `bom.csv`:

1. **Sheet `E-232`** (`drawings/E-232_enlarged_electrical_plans.png`), **Enlarged View `9 / E-232` (EAST CORRIDOR SOUTH (2))**, **Grid Bay `A4`** (located at pixel coordinates `r = 2592, c = 1528`, hall coordinates `x = 25.77 m, y = 4.91 m`).
2. **Sheet `E-233`** (`drawings/E-233_enlarged_electrical_plans.png`), **Enlarged View `13 / E-233` (EAST CORRIDOR NORTH (2))**, **Grid Bay `C4`** (located at pixel coordinates `r = 2727, c = 1528`, hall coordinates `x = 25.77 m, y = 18.63 m`).

---

## 3. Condition Split, Assemblies, and Mounting Heights (Clauses E-10–E-17)

### 3.1 Condition Determination Hierarchy (Clause E-11)
Each device's condition is determined from `drawings/A-102_partition_and_finish_plan.png` and `drawings/E-002_device_and_mounting_schedule.md` (Convention `C8`) together with the four governing conventions:
1. **E-002 Precedence**: Conditions set by `E-002` take precedence over all spatial conditions:
   - `R6` (BRANCH = `EMERGENCY`) -> `EMERGENCY`
   - `R4` (Isolated Ground per `E-002`) -> `IG`
   - `F4` (MOUNTING = `CEILING`) and `D1` (duct smoke detector, carried under `CEILING` wherever located) -> `CEILING`
   - `R7` and `F5` (MOUNTING = `IN ACCESS FLOOR`) -> `ACCESS-FLOOR`
   *(Note: This precedence assigns `CEILING` to `D1` in `E-231` View 1 and `EMERGENCY` to `R6` in `E-231` View 2 even though both lie inside the Entry Vestibule `DAMP` hatch.)*
2. **DAMP Hatch on A-102**: Otherwise, any device located inside an area hatched `DAMP` on `A-102` — the Entry Vestibule (`x ∈ [0.00, 1.50] m, y ∈ [0.30, 8.00] m`) and the 4 Perimeter CRAH condensate aprons (`1.2 m` deep along the South wall, `y ∈ [0.30, 1.50] m`, `x ∈ [0.00, 2.40], [8.40, 10.80], [16.20, 18.60], [24.60, 27.00] m`) — takes condition `DAMP`.
3. **Nearest Wall Centreline on A-102**: Any other drawn device taking a wall condition takes the construction of the nearest wall on `A-102` measured to the wall's centreline:
   - `W-W` (West exterior metal stud wall, centreline `x = 0.075 m`) -> `DRY-STUD`
   - `W-E` (East exterior metal stud wall, centreline `x = 26.925 m`) -> `DRY-STUD`
   - `W-S` (South exterior CMU masonry wall, centreline `y = 0.150 m`) -> `DRY-MASONRY`
   - `W-N` (North exterior CMU masonry wall, centreline `y = 23.850 m`) -> `DRY-MASONRY`
   - `P-R1` (Interior 2-hour fire-rated shaftwall partition, centreline `x = 1.650 m`) -> `RATED-2HR`
4. **Unshown Keyed-Note Devices**: Take the construction of the wall named by the note (`K1` -> `DRY-MASONRY`; `K4` -> wall containing each door on `A-102`, giving `2 RATED-2HR` and `2 DRY-STUD`), or `DRY-STUD` where no wall is named (`K2` -> `28 DRY-STUD`).

### 3.2 Condition Split and Chosen Assemblies per `(type_mark, condition)` Pair (Clauses E-10, E-12, E-14, E-16, E-17)

| Type Mark | Condition | Count | Chosen Catalogue Assembly (Line Item × Multiplicity) | Permitting Specification Clause |
|---|---|---:|---|---|
| `D1` | `CEILING` | 27 | `INS-DUCT-DET` × 1 | Spec 28 31 76 §1.3 & §3.2; Spec 26 05 33 §2.9 & §3.2; UFGS 28 31 76 §3.2.5 |
| `F1` | `DRY-MASONRY` | 8 | `APP-STROBE-120` × 1, `BOX-MAS-4KO` × 1 | Spec 26 05 33 §2.3 & §3.2 (masonry box, no plaster ring) |
| `F1` | `DRY-STUD` | 2 | `APP-STROBE-120` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 05 33 §2.2 & §3.2; Spec 26 20 00 §2.1/§2.4; UFGS 26 20 00 §2.9 |
| `F1` | `RATED-2HR` | 2 | `APP-STROBE-120` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1, `ACC-FIRESTOP-PAD` × 1 | Spec 07 84 00 §2.1 & §3.1; Spec 26 05 33 §2.4 & §3.2; NFPA 70 Art. 300.21; UFC 3-520-01 §3-6.1 |
| `F2` | `DAMP` | 1 | `APP-BS-120` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 20 00 §2.3, §2.5 & §3.3; Spec 26 05 33 §2.5 & §3.2; UFGS 26 20 00 §2.12.2 & §2.9 h |
| `F2` | `DRY-STUD` | 1 | `APP-BS-120` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 05 33 §2.2 & §3.2; Spec 26 20 00 §2.1/§2.4; UFGS 26 20 00 §2.9 |
| `F2` | `RATED-2HR` | 2 | `APP-BS-120` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1, `ACC-FIRESTOP-PAD` × 1 | Spec 07 84 00 §2.1 & §3.1; Spec 26 05 33 §2.4 & §3.2; NFPA 70 Art. 300.21; UFC 3-520-01 §3-6.1 |
| `F3` | `DRY-MASONRY` | 1 | `APP-PULL` × 1, `BOX-MAS-4KO` × 1 | Spec 26 05 33 §2.3 & §3.2 (masonry box, no plaster ring) |
| `F3` | `DRY-STUD` | 1 | `APP-PULL` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 05 33 §2.2 & §3.2; Spec 26 20 00 §2.1/§2.4; UFGS 26 20 00 §2.9 |
| `F3` | `RATED-2HR` | 1 | `APP-PULL` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1, `ACC-FIRESTOP-PAD` × 1 | Spec 07 84 00 §2.1 & §3.1; Spec 26 05 33 §2.4 & §3.2; NFPA 70 Art. 300.21; UFC 3-520-01 §3-6.1 |
| `F4` | `CEILING` | 6 | `DET-PHOTO` × 1, `BOX-4SQ-15` × 1 | Spec 28 31 76 §1.3 & §3.2; Spec 26 05 33 §2.9 & §3.2; UFGS 28 31 76 §3.2.5 |
| `F5` | `ACCESS-FLOOR` | 30 | `DET-PHOTO-UF` × 1, `BOX-4SQ-15` × 1 | Spec 26 05 33 §2.6, §2.9 & §3.2; Spec 28 31 76 §2.3 & §3.2; UFGS 28 31 76 §3.2.5 |
| `J1` | `DAMP` | 2 | `BOX-4SQ-15` × 1, `CVR-4SQ-BLANK` × 1 | Spec 26 20 00 §2.3, §2.5 & §3.3; Spec 26 05 33 §2.5 & §3.2; UFGS 26 20 00 §2.12.2 & §2.9 h |
| `J1` | `DRY-MASONRY` | 18 | `BOX-MAS-4KO` × 1, `CVR-4SQ-BLANK` × 1 | Spec 26 05 33 §2.3 & §3.2 (masonry box, no plaster ring) |
| `J1` | `DRY-STUD` | 5 | `BOX-4SQ-15` × 1, `CVR-4SQ-BLANK` × 1 | Spec 26 05 33 §2.2 & §3.2; Spec 26 20 00 §2.1/§2.4; UFGS 26 20 00 §2.9 |
| `J1` | `RATED-2HR` | 13 | `BOX-4SQ-15` × 1, `CVR-4SQ-BLANK` × 1, `ACC-FIRESTOP-PAD` × 1 | Spec 07 84 00 §2.1 & §3.1; Spec 26 05 33 §2.4 & §3.2; NFPA 70 Art. 300.21; UFC 3-520-01 §3-6.1 |
| `P1` | `DAMP` | 3 | `BOX-PULL-12` × 1 | Spec 26 20 00 §2.3, §2.5 & §3.3; Spec 26 05 33 §2.5 & §3.2; UFGS 26 20 00 §2.12.2 & §2.9 h |
| `P1` | `DRY-STUD` | 3 | `BOX-PULL-12` × 1 | Spec 26 05 33 §2.2 & §3.2; Spec 26 20 00 §2.1/§2.4; UFGS 26 20 00 §2.9 |
| `P1` | `RATED-2HR` | 1 | `BOX-PULL-12` × 1, `ACC-FIRESTOP-PAD` × 1 | Spec 07 84 00 §2.1 & §3.1; Spec 26 05 33 §2.4 & §3.2; NFPA 70 Art. 300.21; UFC 3-520-01 §3-6.1 |
| `R1` | `DAMP` | 3 | `DEV-GFCI-20` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 20 00 §2.3, §2.5 & §3.3; Spec 26 05 33 §2.5 & §3.2; UFGS 26 20 00 §2.12.2 & §2.9 h |
| `R1` | `DRY-MASONRY` | 20 | `DEV-DUP-20` × 1, `BOX-MAS-4KO` × 1 | Spec 26 05 33 §2.3 & §3.2 (masonry box, no plaster ring) |
| `R1` | `DRY-STUD` | 19 | `DEV-DUP-20` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 05 33 §2.2 & §3.2; Spec 26 20 00 §2.1/§2.4; UFGS 26 20 00 §2.9 |
| `R1` | `RATED-2HR` | 10 | `DEV-DUP-20` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1, `ACC-FIRESTOP-PAD` × 1 | Spec 07 84 00 §2.1 & §3.1; Spec 26 05 33 §2.4 & §3.2; NFPA 70 Art. 300.21; UFC 3-520-01 §3-6.1 |
| `R2` | `DRY-MASONRY` | 1 | `DEV-DUP-20` × 2, `BOX-MAS-4KO` × 1 | Spec 26 05 33 §2.3 & §3.2 (masonry box, no plaster ring) |
| `R2` | `DRY-STUD` | 6 | `DEV-DUP-20` × 2, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 05 33 §2.2 & §3.2; Spec 26 20 00 §2.1/§2.4; UFGS 26 20 00 §2.9 |
| `R2` | `RATED-2HR` | 1 | `DEV-DUP-20` × 2, `BOX-4SQ-15` × 1, `RING-1G-58` × 1, `ACC-FIRESTOP-PAD` × 1 | Spec 07 84 00 §2.1 & §3.1; Spec 26 05 33 §2.4 & §3.2; NFPA 70 Art. 300.21; UFC 3-520-01 §3-6.1 |
| `R3` | `DAMP` | 1 | `DEV-GFCI-20` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 20 00 §2.3, §2.5 & §3.3; Spec 26 05 33 §2.5 & §3.2; UFGS 26 20 00 §2.12.2 & §2.9 h |
| `R3` | `DRY-STUD` | 7 | `DEV-GFCI-20` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 05 33 §2.2 & §3.2; Spec 26 20 00 §2.1/§2.4; UFGS 26 20 00 §2.9 |
| `R4` | `IG` | 6 | `DEV-IG-20` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1, `ACC-IG-CONDUCTOR` × 1 | Spec 26 20 00 §2.2; E-002 Note 3; Spec 26 05 33 §3.2; NFPA 70 Art. 250.146(D) |
| `R5` | `DAMP` | 4 | `DEV-GFCI-20` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 20 00 §2.3, §2.5 & §3.3; Spec 26 05 33 §2.5 & §3.2; UFGS 26 20 00 §2.12.2 & §2.9 h |
| `R5` | `DRY-STUD` | 28 | `DEV-GFCI-20` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 05 33 §2.2 & §3.2; Spec 26 20 00 §2.1/§2.4; UFGS 26 20 00 §2.9 |
| `R6` | `EMERGENCY` | 4 | `DEV-DUP-20` × 1, `BOX-4SQ-15` × 1, `RING-1G-58` × 1 | Spec 26 20 00 §3.2; E-002 Note 2; Spec 26 05 33 §3.2; UFC 3-600-01 |
| `R7` | `ACCESS-FLOOR` | 6 | `BOX-FLOOR-2G` × 1 | Spec 26 05 33 §2.6, §2.9 & §3.2; Spec 28 31 76 §2.3 & §3.2; UFGS 28 31 76 §3.2.5 |

- **Fire-Rated Partition Separation (Clause E-14)**: Every box in `RATED-2HR` (partition `P-R1`) carries `1 × ACC-FIRESTOP-PAD` (`Spec 07 84 00` §2.1 & §3.1; `NFPA 70` Art. 300.21), and boxes on opposite faces of `P-R1` maintain at least `300 mm (12 in)` of separation (`UFC 3-520-01` §3-6.1).
- **Isolated Ground (Clause E-16)**: Every `R4` (`IG`) device carries `1 × ACC-IG-CONDUCTOR` in addition to `DEV-IG-20`, `BOX-4SQ-15`, and `RING-1G-58` (`Spec 26 20 00` §2.2; `NFPA 70` Art. 250.146(D)).
- **Emergency Branch Separation (Clause E-17)**: Every `R6` (`EMERGENCY`) device is provided with its own dedicated box (`BOX-4SQ-15` + `RING-1G-58`) and is never combined with a normal-branch device (`Spec 26 20 00` §3.2; `E-002` Note 2; `UFC 3-600-01`).

### 3.3 Scheduled Mounting Heights (Clause E-15)
Per `drawings/E-002_device_and_mounting_schedule.md` (Note 1) and `Spec 26 20 00` §3.1 (`UFGS 26 20 00` §3.1.10), all mounting heights are measured **to the centre of the device or outlet** (except `F3`, measured to the operating handle per `Spec 28 31 76` §3.1 / `UFGS 28 31 76` §3.2.3):
- **`R1`, `R2`, `R3`, `R4`, `R5`, `R6`**: `460 mm (18 in)` above finished floor (AFF) to centre of device.
- **`R7`**: `FLUSH IN FLOOR` (mounted in access floor).
- **`R8`**: `1200 mm` AFF to centre of device (0 quantity on this project).
- **`J1`, `P1`**: `2600 mm` AFF to centre of box.
- **`F1`, `F2`, `F6`**: `2286 mm` AFF to centre of appliance (`F6` has 0 quantity).
- **`F3`**: `1067 mm (42 in)` AFF to operating handle, located within `1.5 m (5 ft)` horizontally of the exit door served.
- **`F4`**: `CEILING` (mounted on ceiling).
- **`F5`**: `IN ACCESS FLOOR` (mounted in raised floor plenum, protecting `21 m² [225 ft²]` per detector per `UFGS 28 31 76` §3.2.5).
- **`D1`**: `AT UNIT` (installed in supply duct at CRAH unit; furnished under Division 23 and installed/wired/interlocked under Division 26 per `Spec 28 31 76` §1.3).

### 3.4 Omission of While-In-Use Hood from Catalogue (Clause E-13)
Specification Section `26 20 00` §2.3 & §2.5 and Section `26 05 33` §2.5 (`UFGS 26 20 00` §2.12.2 and §2.9 h) require a gasketed, weather-resistant, **EXTRA-DUTY** rated while-in-use hood/cover and gasketed wet-location plate for receptacles in `DAMP` locations (and for `R5`). The project catalogue (`product_data/device_catalogue_2026.md`) and price list (`product_data/price_list_2026Q2.md`) carry **no while-in-use hood** (`WHILE-IN-USE` / `EXTRA-DUTY`). Per project instructions, this omission is explicitly stated here in the basis of estimate, and no line item is carried for the while-in-use hood in `bom.csv`.

---

## 4. Spare-Stock, Carton Rounding, and Basket Total (Clauses E-18–E-21)

### 4.1 Pricing and Carton Rounding Method
1. **Required Quantity (`Req`)**: For each catalogue item, `Req` is the sum of `device_count × multiplicity` across all attribution rows in `bom.csv`.
2. **Unit Price Banding (`Clause E-20`)**: For both attribution rows and purchase rows of a given `line_item`, `unit_price` is the rate from `product_data/price_list_2026Q2.md` for the quantity band that item's own **REQUIRED** quantity (`Req`) lands in, **before** spare stock and carton rounding. Every active item's required quantity falls in **Band 2** of its respective price schedule.
3. **Owner's Spare Stock & Whole-Carton Purchase (`Clauses E-18, E-19`)**: Per `project/OPR.md` §4 and `product_data/price_list_2026Q2.md` Term 1, each item's purchase quantity (`for_type_mark = (PURCHASE)`, `condition = (STOCK)`) is at least `Req + 5%` spare stock, rounded **UP** to the next whole carton:
   `Purchased Qty = ceil((Req × 1.05) / Carton) × Carton`.
4. **Basket Total (`Clause E-21`)**: The priced total of the work (the **BASKET TOTAL**) is the sum of `extended_price` (`quantity × unit_price`) across all **attribution rows** in `bom.csv`.

### 4.2 Summary of Catalogue Items, Quantities, Bands, and Extended Prices

| Line Item | Description | Required Qty | Min w/ 5% Spare (`1.05 × Req`) | Carton Qty | Purchased Qty (`(PURCHASE)`/`(STOCK)`) | Unit Price (Band 2) | Attribution Extended | Purchase Extended |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| `ACC-FIRESTOP-PAD` | PAD, FIRESTOP, INTUMESCENT, OUTLET BOX | 30 | 31.50 | 10 | 40 | $94.06 | $2,821.80 | $3,762.40 |
| `ACC-IG-CONDUCTOR` | CONDUCTOR, INSULATED EQUIPMENT GROUNDING, PER DEVICE | 6 | 6.30 | 10 | 10 | $3.36 | $20.16 | $33.60 |
| `APP-BS-120` | APPLIANCE, NOTIFICATION, BUZZER-STROBE, 120 V AC | 4 | 4.20 | 1 | 5 | $70.06 | $280.24 | $350.30 |
| `APP-PULL` | STATION, MANUAL, FIRE ALARM, DOUBLE ACTION | 3 | 3.15 | 1 | 4 | $81.06 | $243.18 | $324.24 |
| `APP-STROBE-120` | APPLIANCE, NOTIFICATION, STROBE, RED, 120 V AC | 12 | 12.60 | 1 | 13 | $299.44 | $3,593.28 | $3,892.72 |
| `BOX-4SQ-15` | BOX, OUTLET, 4 IN SQUARE, 1-1/2 IN DEEP, 1/2 IN KO | 155 | 162.75 | 25 | 175 | $1.99 | $308.45 | $348.25 |
| `BOX-FLOOR-2G` | BOX, FLOOR, RECESSED, STEEL, TWO-GANG | 6 | 6.30 | 1 | 7 | $104.36 | $626.16 | $730.52 |
| `BOX-MAS-4KO` | BOX, MASONRY, 3-1/2 IN DEEP, 4 KO | 48 | 50.40 | 25 | 75 | $22.02 | $1,056.96 | $1,651.50 |
| `BOX-PULL-12` | BOX, PULL, 12 X 12 X 6 IN, SCREW COVER | 7 | 7.35 | 1 | 8 | $34.75 | $243.25 | $278.00 |
| `CVR-4SQ-BLANK` | COVER, 4 IN SQUARE, FLAT BLANK | 38 | 39.90 | 10 | 40 | $0.81 | $30.78 | $32.40 |
| `DET-PHOTO` | DETECTOR, SMOKE, PHOTOELECTRIC, CEILING, WITH BASE | 6 | 6.30 | 1 | 7 | $116.39 | $698.34 | $814.73 |
| `DET-PHOTO-UF` | DETECTOR, SMOKE, PHOTOELECTRIC, ACCESS FLOOR, WITH BASE | 30 | 31.50 | 1 | 32 | $133.02 | $3,990.60 | $4,256.64 |
| `DEV-DUP-20` | RECEPTACLE, DUPLEX, 20 A 125 V, 5-20R, SPEC GRADE | 69 | 72.45 | 10 | 80 | $5.18 | $357.42 | $414.40 |
| `DEV-GFCI-20` | RECEPTACLE, DUPLEX, GFCI, 20 A 125 V, WEATHER-RESISTANT | 43 | 45.15 | 10 | 50 | $20.03 | $861.29 | $1,001.50 |
| `DEV-IG-20` | RECEPTACLE, DUPLEX, ISOLATED GROUND, 20 A 125 V, 5-20R | 6 | 6.30 | 10 | 10 | $24.25 | $145.50 | $242.50 |
| `INS-DUCT-DET` | INSTALLATION OF DUCT SMOKE DETECTOR FURNISHED UNDER DIVISION 23, INCLUDING WIRING AND INTERLOCK | 27 | 28.35 | 1 | 29 | $98.15 | $2,650.05 | $2,846.35 |
| `RING-1G-58` | RING, PLASTER, 4 IN SQUARE, 5/8 IN RAISED, ONE DEVICE | 99 | 103.95 | 25 | 125 | $1.09 | $107.91 | $136.25 |

- **BASKET TOTAL (Sum of Attribution Rows in `bom.csv`)**: **$18,035.37**
- **Total Purchase Value (Sum of `(PURCHASE)`/`(STOCK)` Rows including 5% Spare & Carton Rounding)**: **$21,116.30**
